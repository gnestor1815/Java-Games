package DatingSim;

import java.io.*;
import java.util.*;

public class Scenes {

	public static int sceneNum = 0;
	public static int sceneType = 0;
	
	public static String nextLine[] = new String[1000000];
	
	public static void fileScan() {

	int i = 0;
	Scanner inputFile = null;
	String nxtLine = "";
	try {
		inputFile = new Scanner(new File("TestScript.txt"));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	while (inputFile.hasNextLine()) {
		nextLine[0 + i] = inputFile.nextLine();
		i++;
	}
	
	}
	
}
