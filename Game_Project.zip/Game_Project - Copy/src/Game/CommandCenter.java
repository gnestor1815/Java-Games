package Game;

public class CommandCenter {
static double commandNum = 0.0;
	
	static void createComNum() {
		if (GameBase.command1.toLowerCase().equals("move")) {
			if (GameBase.command2.toLowerCase().equals("forward")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("straight")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("backward")) {
				commandNum = 1.2;
			} else if (GameBase.command2.toLowerCase().equals("back")) {
				commandNum = 1.2;
			} else if (GameBase.command2.toLowerCase().equals("right")) {
				commandNum = 1.3;
			} else if (GameBase.command2.toLowerCase().equals("left")) {
				commandNum = 1.4;
			} else if (GameBase.command2.toLowerCase().equals("up")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("down")) {
				commandNum = 1.2;
			} else {
				commandNum = 0.0;
			}
			
			if (Scenes.monkeyCount >= 1) {
				System.out.println("YOU HAVE BEEN SQUOZE");
				System.out.println("\\     /\\  / | \\  /  ");
				System.out.println("|     ||  | | |  |  ");
				System.out.println("|     ||  | . |  |  ");
				System.out.println("\\__   /\\_ |   \\  /  ");
				System.out.println("   \\_|   \\|    |/   ");
				System.out.println("     .    |    |    ");
				System.out.println("     :    '    .    ");
				Main2.g = 1;
			}
		} else if (GameBase.command1.toLowerCase().equals("go")) {
			if (GameBase.command2.toLowerCase().equals("forward")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("straight")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("backward")) {
				commandNum = 1.2;
			} else if (GameBase.command2.toLowerCase().equals("back")) {
				commandNum = 1.2;
			} else if (GameBase.command2.toLowerCase().equals("right")) {
				commandNum = 1.3;
			} else if (GameBase.command2.toLowerCase().equals("left")) {
				commandNum = 1.4;
			} else if (GameBase.command2.toLowerCase().equals("up")) {
				commandNum = 1.1;
			} else if (GameBase.command2.toLowerCase().equals("down")) {
				commandNum = 1.2;
			} else {
				commandNum = 0.0;
			}
			
			if (Scenes.monkeyCount >= 1) {
				System.out.println("YOU HAVE BEEN SQUOZE");
				System.out.println("\\     /\\  / | \\  /  ");
				System.out.println("|     ||  | | |  |  ");
				System.out.println("|     ||  | . |  |  ");
				System.out.println("\\__   /\\_ |   \\  /  ");
				System.out.println("   \\_|   \\|    |/   ");
				System.out.println("     .    |    |    ");
				System.out.println("     :    '    .    ");
				Main2.g = 1;
			}
		} else if (GameBase.command1.toLowerCase().equals("grab")) {
			if (GameBase.command2.toLowerCase().equals("banana")) {
				commandNum = 2.1;
			} else if (GameBase.command2.toLowerCase().equals("nanner")) {
				commandNum = 2.1;
			} else if (GameBase.command2.toLowerCase().equals("water")) {
				commandNum = 2.2;
			} else if (GameBase.command2.toLowerCase().equals("bottle")) {
				commandNum = 2.2;
			} else if (GameBase.command2.toLowerCase().equals("flashlight")) {
				commandNum = 2.3;
			} else if (GameBase.command2.toLowerCase().equals("benji")) {
				commandNum = 2.4;
			} else {
				commandNum = 0.0;
			}
		} else if (GameBase.command1.toLowerCase().equals("take")) {
			if (GameBase.command2.toLowerCase().equals("banana")) {
				commandNum = 2.1;
			} else if (GameBase.command2.toLowerCase().equals("nanner")) {
				commandNum = 2.1;
			} else if (GameBase.command2.toLowerCase().equals("water")) {
				commandNum = 2.2;
			} else if (GameBase.command2.toLowerCase().equals("bottle")) {
				commandNum = 2.2;
			} else if (GameBase.command2.toLowerCase().equals("flashlight")) {
				commandNum = 2.3;
			} else if (GameBase.command2.toLowerCase().equals("benji")) {
				commandNum = 2.4;
			} else {
				commandNum = 0.0;
			}
		} else if (GameBase.command1.toLowerCase().equals("use")) {
			if (GameBase.command2.toLowerCase().equals("banana")) {
				commandNum = 3.1;
			} else if (GameBase.command2.toLowerCase().equals("water")) {
				commandNum = 3.2;
			} else if (GameBase.command2.toLowerCase().equals("bottle")) {
				commandNum = 3.2;
			} else if (GameBase.command2.toLowerCase().equals("flashlight")) {
				commandNum = 3.3;
			} else if (GameBase.command2.toLowerCase().equals("benji")) {
				commandNum = 3.4;
			} else {
				commandNum = 0.0;
			}
		} else if (GameBase.command1.toLowerCase().equals("quit")) {
			System.out.println("Thank you for playing!");
			Main2.g = 3;
		} else if (GameBase.command1.toLowerCase().equals("check")) {
			if (GameBase.command2.toLowerCase().equals("inventory")) {
				System.out.println("Inventory:");
				System.out.print("Bananas:");
				System.out.println(Player.bananaCount);
				System.out.print("Bottles:");
				System.out.println(Player.bottleCount);
				System.out.print("Flashlight:");
				System.out.println(" Who cares");
				System.out.print("Benji: ");
				System.out.println(Player.benji);
				commandNum = 0.0;
			} 
	}else {
		commandNum = 0.0;
	}
	}
}
