package DatingSim;

import java.awt.*;
import javax.swing.*;


public class Main extends JFrame{
	static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	static int s_Width = (int) screenSize.getWidth();
	static int s_Height = (int) screenSize.getHeight();
	public Main() {
		Scenes2.fileScan();
		initUI();
	}
	
	private void initUI() {
		
		Board2 board = new Board2();
		board.setOpaque(false);
		getContentPane().add(board);
		setSize(s_Width, s_Height);
        setTitle("Dating Sim FG");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
	}
	
	public static void main(String[] args) {

        EventQueue.invokeLater(() -> {
            Main ex = new Main();
            ex.setVisible(true);
        });
    }
}
