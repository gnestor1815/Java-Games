package Game;

import java.io.File;

public class EndGame {
	static void Timer() throws InterruptedException {
		File beepsPath = new File("blip.wav");
		File beeps = new File(beepsPath.getAbsolutePath());
		File endPath = new File("congrats.wav");
		File end = new File(endPath.getAbsolutePath());
			Thread.sleep(5000);
		Main2.PlaySound(beeps);
		System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCCT: You...");
			Thread.sleep(3000);
			Main2.PlaySound(beeps);
		System.out.println("\n\n\nCCT: You used benji...");

			Thread.sleep(3000);
			Main2.PlaySound(beeps);
		System.out.println("\n\n\nCCT: I'm watching you...");

			Thread.sleep(5000);
			Main2.PlaySound(beeps);
			System.out.print("\n\n\nT");
			Thread.sleep(430);
			Main2.PlaySound(beeps);
			System.out.print("h");
			Thread.sleep(680);
			Main2.PlaySound(beeps);
			System.out.print("e");
			Thread.sleep(720);
			System.out.print(" ");
			Thread.sleep(500);
			Main2.PlaySound(beeps);
			System.out.print("E");
			Thread.sleep(310);
			Main2.PlaySound(beeps);
			System.out.print("n");
			Thread.sleep(810);
			Main2.PlaySound(beeps);
			System.out.print("d\n\n\n\n");
			Thread.sleep(2000);
			Main2.PlaySound(beeps);
			System.out.print("for now...");
			Thread.sleep(1000);
			
			
			Main2.PlaySound(end);
			Thread.sleep(1000);
			Main2.PlaySound(beeps);
		System.out.println("\n\n\nA Game By Gabriel Nestor");
		
		Thread.sleep(1000);
		
		Main2.PlaySound(beeps);
		System.out.println("\n\n\nScenes written by Alex Flores");
	}
	
}
