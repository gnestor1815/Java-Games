package Game;

import java.awt.*;
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.util.*;


public class Main2 {
	static File blipPath = new File("blip.wav");
	static File blip = new File(blipPath.getAbsolutePath());
	static int g = 0;
	public static void main(String [] args) throws InterruptedException {
		Scanner input = new Scanner(System.in);
		System.out.println(blip.getAbsolutePath());
		int b = 0;
		gameStart();
		while (b != 1) {
			System.out.println("Play Again?");
			String response = input.nextLine();
			if (response.toLowerCase().equals("yes")) {
				g = 0;
				Scenes.numScene = 0;
				Scenes.monkeyCount = 0;
				Scenes.benjiUse = 0;
				Scenes.x = 0;
				Player.bananaCount = 0;
				Player.bottleCount = 0;
				Player.flashCount = 0;
				Monkeys.monkey1Loc = 21;
				Monkeys.monkey2Loc = 33;
				Monkeys.monkey3Loc = 19;
				Monkeys.kevin = 45;
				gameStart();
			} else if (response.toLowerCase().equals("no")) {
				b = 1;
			}
		}
		
		
	}
	static void PlaySound(File Sound) {
		try {
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(Sound));
			clip.start();
		} catch(Exception e) {
			System.out.println("Something went wrong.");
		}
	}
	public static void gameStart() throws InterruptedException {
		PlaySound(blip);
		System.out.print("Starting Game");
		Thread.sleep(500);
		System.out.print(".");
		Thread.sleep(500);
		System.out.print(".");
		Thread.sleep(500);
		System.out.println(".");
		
		while (g < 1) {
			PlaySound(blip);
			Scenes.sceneRun();
			Monkeys.movingMonkeys();
			Monkeys.movingMonkeys();
			PlaySound(blip);
			Scenes.sceneCheck();
			PlaySound(blip);
			GameBase.runInput();
			CommandCenter.createComNum();
			CommandTranslate.commTrans();
		}
		if (g == 2) {
			EndGame.Timer();
		}
	}
}
