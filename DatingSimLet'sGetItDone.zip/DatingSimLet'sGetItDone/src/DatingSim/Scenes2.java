package DatingSim;

import java.io.*;
import java.util.*;

public class Scenes2 {

	public static int sceneNum = 0;
	public static int sceneType = 0;
	

	
	public static String bckgrnd[] = new String[1000000];
	public static String spkChrctr[] = new String[1000000];
	public static String UnslctChrctr[] = new String[1000000];
	public static String spScn[] = new String[1000000];
	public static String nextLn[] = new String[1000000];
	
	
	public static void fileScan() {

	int i = 0;
	Scanner inputFile = null;
	
	try {
		inputFile = new Scanner(new File("TestScript.txt"));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	while (inputFile.hasNextLine()) {
		
		String split[] = inputFile.nextLine().split("/");
		if (split.length == 5) {
		bckgrnd[i] = split[0];
		spkChrctr[i] = split[1];
		UnslctChrctr[i] = split[2];
		spScn[i] = split[3];
		nextLn[i] = split[4];
		i++;
		}
	}
	
	}
	
}
