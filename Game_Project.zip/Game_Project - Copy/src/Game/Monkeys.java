package Game;

import java.util.concurrent.ThreadLocalRandom;

public class Monkeys {

	static int monkey1Loc = 21;
	 static int monkey2Loc = 33;
	 static int monkey3Loc = 19;
	 static int kevin = 45;
	 
	
	 static void movingMonkeys() {
		 int monkey1change = ThreadLocalRandom.current().nextInt(1, 4 + 1);
		 int monkey2change = ThreadLocalRandom.current().nextInt(1, 4 + 1);
		 int monkey3change = ThreadLocalRandom.current().nextInt(1, 4 + 1);
		 int kevinchange = ThreadLocalRandom.current().nextInt(1, 4 + 1);
		 
		 if (monkey1Loc == Scenes.numScene) {
			 monkey1change = 0;
			 monkey2change = 0;
			 monkey3change = 0;
			 kevinchange = 0;
		 } else if (monkey2Loc == Scenes.numScene) {
			 monkey1change = 0;
			 monkey2change = 0;
			 monkey3change = 0;
			 kevinchange = 0;
		 } else if (monkey3Loc == Scenes.numScene) {
			 monkey1change = 0;
			 monkey2change = 0;
			 monkey3change = 0;
			 kevinchange = 0;
		 } else if (kevin == Scenes.numScene) {
			 monkey1change = 0;
			 monkey2change = 0;
			 monkey3change = 0;
			 kevinchange = 0;
		 }
		 
		 if (Monkeys.monkey1Loc == 1) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 8;	 
				}  
			} else if (Monkeys.monkey1Loc == 8) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 15;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 36;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 1;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 36;	 
				} 
			} else if (Monkeys.monkey1Loc == 15) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 16;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 29;	 
				} 
			} else if (Monkeys.monkey1Loc == 22) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 12;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 49;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 49;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 49;	 
				} 
			} else if (Monkeys.monkey1Loc == 29) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 30;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 2;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 30;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 2;	 
				} 
			} else if (Monkeys.monkey1Loc == 36) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 17;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 8;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 17;	 
				} 
			}  else if (Monkeys.monkey1Loc == 43) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 12;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 38;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 33;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 38;	 
				}  
			} else if (Monkeys.monkey1Loc == 2) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 33;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 29;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 33;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 29;	 
				} 
			} else if (Monkeys.monkey1Loc == 3) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 10;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 34;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 10;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 34;	 
				} 
			} else if (Monkeys.monkey1Loc == 4) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 41;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 13;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 13;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 41;	 
				} 
			} else if (Monkeys.monkey1Loc == 5) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 6;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 48;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 48;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 6;	 
				} 
			} else if (Monkeys.monkey1Loc == 6) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 9;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 5;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 9;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 5;	 
				} 
			} else if (Monkeys.monkey1Loc == 7) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 11;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 20;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 45;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 20;	 
				} 
			} else if (Monkeys.monkey1Loc == 14) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 39;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 26;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 39;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 26;	 
				} 
			} else if (Monkeys.monkey1Loc == 21) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 40;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 40;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 49;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 40;	 
				} 
			} else if (Monkeys.monkey1Loc == 28) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 35;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 34;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 31;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 34;	 
				} 
			} else if (Monkeys.monkey1Loc == 35) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 13;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 28;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 13;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 28;	 
				} 
			} else if (Monkeys.monkey1Loc == 42) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 39;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 49;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 39;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 49;	 
				} 
			} else if (Monkeys.monkey1Loc == 49) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 42;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 22;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 21;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 22;	 
				} 	 
			} else if (Monkeys.monkey1Loc == 44) {
				if (monkey1change == 1) {
					Monkeys.monkey1Loc = 45;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 31;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 45;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 31;	 
				} 
			} else if (Monkeys.monkey1Loc == 45) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 44;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 46;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 46;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 44;	 
				} 
			} else if (Monkeys.monkey1Loc == 46) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 47;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 45;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 45;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 47;	 
				} 
			} else if (Monkeys.monkey1Loc == 47) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 40;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 46;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 26;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 46;	 
				} 
			} else if (Monkeys.monkey1Loc == 48) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 12;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 5;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 5;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 12;	 
				} 
			}  else if (Monkeys.monkey1Loc == 9) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 24;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 6;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 33;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 24;	 
				} 
			} else if (Monkeys.monkey1Loc == 10) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 3;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 17;
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 3;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 17;	 
				} 
			} else if (Monkeys.monkey1Loc == 11) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 37;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 7;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 7;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 37;	 
				} 
			} else if (Monkeys.monkey1Loc == 12) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 43;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 48;
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 48;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 17;	 
				} 
			} else if (Monkeys.monkey1Loc == 13) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 35;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 4;
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 35;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 4;	 
				} 
			} else if (Monkeys.monkey1Loc == 16) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 15;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 23;
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 15;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 23;	 
				} 
			} else if (Monkeys.monkey1Loc == 17) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 10;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 36;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 10;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 36;	 
				} 
			} else if (Monkeys.monkey1Loc == 18) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 19;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 25;
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 19;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 25;	 
				} 
			} else if (Monkeys.monkey1Loc == 19) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 18;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 18;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 27;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 18;	 
				} 
			} else if (Monkeys.monkey1Loc == 20) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 26;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 7;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 26;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 7;	 
				} 
			} else if (Monkeys.monkey1Loc == 23) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 16;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 30;
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 16;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 30;	 
				} 
			} else if (Monkeys.monkey1Loc == 24) {
				if (monkey1change == 3) {
					Monkeys.monkey1Loc = 9;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 37;
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 9;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 37;	 
				} 
			} else if (Monkeys.monkey1Loc == 25) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 18;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 32;
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 18;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 32;	 
				} 
			} else if (Monkeys.monkey1Loc == 26) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 14;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 20;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 14;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 20;	 
				} 
			} else if (Monkeys.monkey1Loc == 27) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 38;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 38;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 38;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 38;	 
				} 
			}  else if (Monkeys.monkey1Loc == 30) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 23;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 31;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 29;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 23;	 
				} 
			} else if (Monkeys.monkey1Loc == 31) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 32;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 30;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 44;
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 32;	 
				} 
			} else if (Monkeys.monkey1Loc == 32) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 25;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 31;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 25;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 31;	 
				} 
			} else if (Monkeys.monkey1Loc == 33) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 2;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 2;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 2;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 2;	 
				} 
			} else if (Monkeys.monkey1Loc == 34) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 3;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 28;	 
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 3;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 28;	 
				} 
			} else if (Monkeys.monkey1Loc == 37) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 24;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 11;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 11;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 24;	 
				} 
			} else if (Monkeys.monkey1Loc == 38) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 41;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 27;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 43;
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 41;	 
				} 
			} else if (Monkeys.monkey1Loc == 39) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 42;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 14;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 42;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 14;	 
				} 
			} else if (Monkeys.monkey1Loc == 40) {
				if (monkey1change == 4) {
					Monkeys.monkey1Loc = 21;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 47;
				} else if (monkey1change == 2) {
					Monkeys.monkey1Loc = 47;	 
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 47;	 
				} 
			} else if (Monkeys.monkey1Loc == 41) {
				if (monkey1change == 2) {
					Monkeys.monkey1Loc = 4;	 
				} else if (monkey1change == 1) {
					Monkeys.monkey1Loc = 38;
				} else if (monkey1change == 3) {
					Monkeys.monkey1Loc = 4;	 
				} else if (monkey1change == 4) {
					Monkeys.monkey1Loc = 38;	 
				} 
			}
		 
		 if (Monkeys.monkey2Loc == 1) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 8;	 
				}  
			} else if (Monkeys.monkey2Loc == 8) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 15;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 36;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 1;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 36;	 
				} 
			} else if (Monkeys.monkey2Loc == 15) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 16;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 29;	 
				} 
			} else if (Monkeys.monkey2Loc == 22) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 12;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 49;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 49;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 49;	 
				} 
			} else if (Monkeys.monkey2Loc == 29) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 30;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 2;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 30;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 2;	 
				} 
			} else if (Monkeys.monkey2Loc == 36) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 17;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 8;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 17;	 
				} 
			}  else if (Monkeys.monkey2Loc == 43) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 12;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 38;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 33;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 38;	 
				}  
			} else if (Monkeys.monkey2Loc == 2) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 33;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 29;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 33;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 29;	 
				} 
			} else if (Monkeys.monkey2Loc == 3) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 10;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 34;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 10;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 34;	 
				} 
			} else if (Monkeys.monkey2Loc == 4) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 41;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 13;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 13;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 41;	 
				} 
			} else if (Monkeys.monkey2Loc == 5) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 6;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 48;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 48;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 6;	 
				} 
			} else if (Monkeys.monkey2Loc == 6) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 9;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 5;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 9;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 5;	 
				} 
			} else if (Monkeys.monkey2Loc == 7) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 11;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 20;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 45;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 20;	 
				} 
			} else if (Monkeys.monkey2Loc == 14) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 39;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 26;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 39;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 26;	 
				} 
			} else if (Monkeys.monkey2Loc == 21) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 40;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 40;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 49;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 40;	 
				} 
			} else if (Monkeys.monkey2Loc == 28) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 35;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 34;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 31;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 34;	 
				} 
			} else if (Monkeys.monkey2Loc == 35) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 13;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 28;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 13;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 28;	 
				} 
			} else if (Monkeys.monkey2Loc == 42) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 39;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 49;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 39;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 49;	 
				} 
			} else if (Monkeys.monkey2Loc == 49) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 42;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 22;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 21;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 22;	 
				} 	 
			} else if (Monkeys.monkey2Loc == 44) {
				if (monkey2change == 1) {
					Monkeys.monkey2Loc = 45;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 31;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 45;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 31;	 
				} 
			} else if (Monkeys.monkey2Loc == 45) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 44;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 46;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 46;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 44;	 
				} 
			} else if (Monkeys.monkey2Loc == 46) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 47;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 45;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 45;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 47;	 
				} 
			} else if (Monkeys.monkey2Loc == 47) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 40;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 46;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 26;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 46;	 
				} 
			} else if (Monkeys.monkey2Loc == 48) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 12;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 5;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 5;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 12;	 
				} 
			}  else if (Monkeys.monkey2Loc == 9) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 24;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 6;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 33;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 24;	 
				} 
			} else if (Monkeys.monkey2Loc == 10) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 3;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 17;
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 3;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 17;	 
				} 
			} else if (Monkeys.monkey2Loc == 11) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 37;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 7;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 7;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 37;	 
				} 
			} else if (Monkeys.monkey2Loc == 12) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 43;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 48;
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 48;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 17;	 
				} 
			} else if (Monkeys.monkey2Loc == 13) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 35;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 4;
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 35;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 4;	 
				} 
			} else if (Monkeys.monkey2Loc == 16) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 15;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 23;
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 15;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 23;	 
				} 
			} else if (Monkeys.monkey2Loc == 17) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 10;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 36;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 10;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 36;	 
				} 
			} else if (Monkeys.monkey2Loc == 18) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 19;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 25;
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 19;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 25;	 
				} 
			} else if (Monkeys.monkey2Loc == 19) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 18;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 18;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 27;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 18;	 
				} 
			} else if (Monkeys.monkey2Loc == 20) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 26;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 7;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 26;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 7;	 
				} 
			} else if (Monkeys.monkey2Loc == 23) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 16;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 30;
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 16;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 30;	 
				} 
			} else if (Monkeys.monkey2Loc == 24) {
				if (monkey2change == 3) {
					Monkeys.monkey2Loc = 9;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 37;
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 9;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 37;	 
				} 
			} else if (Monkeys.monkey2Loc == 25) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 18;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 32;
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 18;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 32;	 
				} 
			} else if (Monkeys.monkey2Loc == 26) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 14;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 20;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 14;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 20;	 
				} 
			} else if (Monkeys.monkey2Loc == 27) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 38;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 38;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 38;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 38;	 
				} 
			}  else if (Monkeys.monkey2Loc == 30) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 23;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 31;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 29;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 23;	 
				} 
			} else if (Monkeys.monkey2Loc == 31) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 32;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 30;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 44;
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 32;	 
				} 
			} else if (Monkeys.monkey2Loc == 32) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 25;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 31;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 25;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 31;	 
				} 
			} else if (Monkeys.monkey2Loc == 33) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 2;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 2;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 2;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 2;	 
				} 
			} else if (Monkeys.monkey2Loc == 34) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 3;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 28;	 
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 3;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 28;	 
				} 
			} else if (Monkeys.monkey2Loc == 37) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 24;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 11;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 11;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 24;	 
				} 
			} else if (Monkeys.monkey2Loc == 38) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 41;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 27;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 43;
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 41;	 
				} 
			} else if (Monkeys.monkey2Loc == 39) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 42;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 14;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 42;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 14;	 
				} 
			} else if (Monkeys.monkey2Loc == 40) {
				if (monkey2change == 4) {
					Monkeys.monkey2Loc = 21;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 47;
				} else if (monkey2change == 2) {
					Monkeys.monkey2Loc = 47;	 
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 47;	 
				} 
			} else if (Monkeys.monkey2Loc == 41) {
				if (monkey2change == 2) {
					Monkeys.monkey2Loc = 4;	 
				} else if (monkey2change == 1) {
					Monkeys.monkey2Loc = 38;
				} else if (monkey2change == 3) {
					Monkeys.monkey2Loc = 4;	 
				} else if (monkey2change == 4) {
					Monkeys.monkey2Loc = 38;	 
				} 
			}

		 
		
		 if (Monkeys.monkey3Loc == 1) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 8;	 
				}  
			} else if (Monkeys.monkey3Loc == 8) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 15;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 36;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 1;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 36;	 
				} 
			} else if (Monkeys.monkey3Loc == 15) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 16;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 29;	 
				} 
			} else if (Monkeys.monkey3Loc == 22) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 12;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 49;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 49;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 49;	 
				} 
			} else if (Monkeys.monkey3Loc == 29) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 30;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 2;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 30;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 2;	 
				} 
			} else if (Monkeys.monkey3Loc == 36) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 17;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 8;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 17;	 
				} 
			}  else if (Monkeys.monkey3Loc == 43) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 12;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 38;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 33;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 38;	 
				}  
			} else if (Monkeys.monkey3Loc == 2) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 33;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 29;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 33;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 29;	 
				} 
			} else if (Monkeys.monkey3Loc == 3) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 10;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 34;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 10;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 34;	 
				} 
			} else if (Monkeys.monkey3Loc == 4) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 41;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 13;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 13;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 41;	 
				} 
			} else if (Monkeys.monkey3Loc == 5) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 6;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 48;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 48;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 6;	 
				} 
			} else if (Monkeys.monkey3Loc == 6) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 9;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 5;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 9;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 5;	 
				} 
			} else if (Monkeys.monkey3Loc == 7) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 11;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 20;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 45;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 20;	 
				} 
			} else if (Monkeys.monkey3Loc == 14) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 39;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 26;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 39;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 26;	 
				} 
			} else if (Monkeys.monkey3Loc == 21) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 40;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 40;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 49;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 40;	 
				} 
			} else if (Monkeys.monkey3Loc == 28) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 35;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 34;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 31;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 34;	 
				} 
			} else if (Monkeys.monkey3Loc == 35) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 13;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 28;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 13;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 28;	 
				} 
			} else if (Monkeys.monkey3Loc == 42) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 39;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 49;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 39;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 49;	 
				} 
			} else if (Monkeys.monkey3Loc == 49) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 42;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 22;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 21;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 22;	 
				} 	 
			} else if (Monkeys.monkey3Loc == 44) {
				if (monkey3change == 1) {
					Monkeys.monkey3Loc = 45;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 31;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 45;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 31;	 
				} 
			} else if (Monkeys.monkey3Loc == 45) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 44;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 46;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 46;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 44;	 
				} 
			} else if (Monkeys.monkey3Loc == 46) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 47;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 45;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 45;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 47;	 
				} 
			} else if (Monkeys.monkey3Loc == 47) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 40;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 46;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 26;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 46;	 
				} 
			} else if (Monkeys.monkey3Loc == 48) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 12;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 5;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 5;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 12;	 
				} 
			}  else if (Monkeys.monkey3Loc == 9) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 24;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 6;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 33;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 24;	 
				} 
			} else if (Monkeys.monkey3Loc == 10) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 3;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 17;
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 3;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 17;	 
				} 
			} else if (Monkeys.monkey3Loc == 11) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 37;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 7;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 7;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 37;	 
				} 
			} else if (Monkeys.monkey3Loc == 12) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 43;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 48;
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 48;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 17;	 
				} 
			} else if (Monkeys.monkey3Loc == 13) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 35;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 4;
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 35;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 4;	 
				} 
			} else if (Monkeys.monkey3Loc == 16) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 15;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 23;
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 15;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 23;	 
				} 
			} else if (Monkeys.monkey3Loc == 17) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 10;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 36;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 10;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 36;	 
				} 
			} else if (Monkeys.monkey3Loc == 18) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 19;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 25;
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 19;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 25;	 
				} 
			} else if (Monkeys.monkey3Loc == 19) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 18;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 18;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 27;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 18;	 
				} 
			} else if (Monkeys.monkey3Loc == 20) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 26;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 7;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 26;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 7;	 
				} 
			} else if (Monkeys.monkey3Loc == 23) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 16;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 30;
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 16;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 30;	 
				} 
			} else if (Monkeys.monkey3Loc == 24) {
				if (monkey3change == 3) {
					Monkeys.monkey3Loc = 9;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 37;
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 9;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 37;	 
				} 
			} else if (Monkeys.monkey3Loc == 25) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 18;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 32;
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 18;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 32;	 
				} 
			} else if (Monkeys.monkey3Loc == 26) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 14;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 20;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 14;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 20;	 
				} 
			} else if (Monkeys.monkey3Loc == 27) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 38;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 38;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 38;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 38;	 
				} 
			}  else if (Monkeys.monkey3Loc == 30) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 23;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 31;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 29;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 23;	 
				} 
			} else if (Monkeys.monkey3Loc == 31) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 32;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 30;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 44;
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 32;	 
				} 
			} else if (Monkeys.monkey3Loc == 32) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 25;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 31;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 25;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 31;	 
				} 
			} else if (Monkeys.monkey3Loc == 33) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 2;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 2;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 2;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 2;	 
				} 
			} else if (Monkeys.monkey3Loc == 34) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 3;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 28;	 
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 3;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 28;	 
				} 
			} else if (Monkeys.monkey3Loc == 37) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 24;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 11;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 11;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 24;	 
				} 
			} else if (Monkeys.monkey3Loc == 38) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 41;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 27;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 43;
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 41;	 
				} 
			} else if (Monkeys.monkey3Loc == 39) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 42;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 14;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 42;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 14;	 
				} 
			} else if (Monkeys.monkey3Loc == 40) {
				if (monkey3change == 4) {
					Monkeys.monkey3Loc = 21;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 47;
				} else if (monkey3change == 2) {
					Monkeys.monkey3Loc = 47;	 
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 47;	 
				} 
			} else if (Monkeys.monkey3Loc == 41) {
				if (monkey3change == 2) {
					Monkeys.monkey3Loc = 4;	 
				} else if (monkey3change == 1) {
					Monkeys.monkey3Loc = 38;
				} else if (monkey3change == 3) {
					Monkeys.monkey3Loc = 4;	 
				} else if (monkey3change == 4) {
					Monkeys.monkey3Loc = 38;	 
				} 
			}

		

		 if (kevin >= 49) {
			 kevin = 2;
		 } else if (kevin < 1) {
			 kevin = 48;
		 }
		 
		 if (kevinchange == 1) {
			 kevin += 7;
		 } else if (kevinchange == 2) {
			 kevin -= 7;
		 } else if (kevinchange == 3) {
			 kevin += 1;
		 } else if (kevinchange == 4) {
			 kevin -= 1;
		 } 
		 
	 }
	
}
