package Game;

import java.util.Scanner;

public class GameBase {
	static String commandLine = ". .";
	static String command1 = ".";
	static String command2 = ".";
	
	static void runInput() {
		Scanner input = new Scanner(System.in);
		System.out.println("What do you want to do?");
		commandLine = input.nextLine();
		
		try {
		String [] commWords = commandLine.split(" ");
		command1 = commWords[0];
		command2 = commWords[1];
		}
		catch (Exception ie) {
			System.out.println("If you need help here's a list of commands you can use: \nMove (Forward, Backward, Right, Left)\nGrab/Use (water, bottle, banana, flashlight, benji)\nQuit Game\nCheck Inventory");
			command1 = "dont";
			command2 = "move";
			CommandCenter.commandNum = 0.0;
		}
		
	}
	
	
}
