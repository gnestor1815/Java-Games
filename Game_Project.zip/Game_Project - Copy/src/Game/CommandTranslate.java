package Game;

public class CommandTranslate {


	static void commTrans() {
		if (Scenes.numScene == 0) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene += 1;	 
			} else {
				System.out.println("Please say: move forward");
			}
		} else if (Scenes.numScene == 1) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 8;	 
			} 	 
		} else if (Scenes.numScene == 8) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 15;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 36;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 1;	 
			} 
		} else if (Scenes.numScene == 15) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 16;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 8;	 
			} 
		} else if (Scenes.numScene == 22) {
			if (CommandCenter.commandNum == 1.4) {
				if (Player.flashCount == 2) {
					try {
						Thread.sleep(20000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				System.out.println("What is that?");
				Scenes.numScene = 49;	
				} else {
					Monkeys.kevin = 22;
				}
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 32;	
			}
		} else if (Scenes.numScene == 29) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 44;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 2;	 
			} 
		} else if (Scenes.numScene == 36) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 8;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 17;	 
			} 
		}  else if (Scenes.numScene == 43) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 12;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 38;	 
			} 	 
		} else if (Scenes.numScene == 2) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 33;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 29;	 
			}
		} else if (Scenes.numScene == 3) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 10;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 34;	 
			} 
		} else if (Scenes.numScene == 4) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 41;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 13;	 
			} 
		} else if (Scenes.numScene == 5) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 6;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 48;	 
			} 
		} else if (Scenes.numScene == 6) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 9;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 5;	 
			} 
		} else if (Scenes.numScene == 7) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 11;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 20;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 37;	 
			}
		} else if (Scenes.numScene == 14) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 39;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 26;	 
			} 
		} else if (Scenes.numScene == 21) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 40;	 
			} 
		} else if (Scenes.numScene == 28) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 35;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 34;	 
			} 
		} else if (Scenes.numScene == 35) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 13;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 28;	 
			} 
		} else if (Scenes.numScene == 42) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 39;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 49;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 37;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 37;	 
			} 
		} else if (Scenes.numScene == 49) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 42;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 22;	 
			} 	 
		} else if (Scenes.numScene == 44) {
			if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 45;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 31;	 
			} 
		} else if (Scenes.numScene == 45) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 44;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 46;	 
			} 
		} else if (Scenes.numScene == 46) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 47;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 45;	 
			} 
		} else if (Scenes.numScene == 47) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 40;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 46;	 
			} 
		} else if (Scenes.numScene == 48) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 12;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 5;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 19;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 8;	 
			}
		}  else if (Scenes.numScene == 9) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 24;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 6;	 
			}
		} else if (Scenes.numScene == 10) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 3;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 17;
			}
		} else if (Scenes.numScene == 11) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 37;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 7;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 37;	 
			}
		} else if (Scenes.numScene == 12) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 43;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 48;
			}
		} else if (Scenes.numScene == 13) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 2;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 4;
			}
		} else if (Scenes.numScene == 16) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 15;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 23;
			}
		} else if (Scenes.numScene == 17) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 10;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 36;	 
			} 
		} else if (Scenes.numScene == 18) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 19;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 25;
			}
		} else if (Scenes.numScene == 19) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 18;	 
			}
		} else if (Scenes.numScene == 20) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 26;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 7;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 37;	 
			}
		} else if (Scenes.numScene == 23) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 16;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 30;
			}
		} else if (Scenes.numScene == 24) {
			if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 9;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 37;
			}
		} else if (Scenes.numScene == 25) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 18;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 32;
			}
		} else if (Scenes.numScene == 26) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 14;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 20;	 
			} else if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 37;	 
			}
		} else if (Scenes.numScene == 27) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 38;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 31;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 1;	 
			}
		}  else if (Scenes.numScene == 30) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 23;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 31;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 29;	 
			} 
		} else if (Scenes.numScene == 31) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 32;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 30;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 44;
			}
		} else if (Scenes.numScene == 32) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 25;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 31;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 22;	 
			}
		} else if (Scenes.numScene == 33) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 2;	 
			} 
		} else if (Scenes.numScene == 34) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 3;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 28;	 
			} 
		} else if (Scenes.numScene == 37) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 24;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 11;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 30;	 
			}
		} else if (Scenes.numScene == 38) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 41;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 27;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 43;
			}
		} else if (Scenes.numScene == 39) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 42;	 
			} else if (CommandCenter.commandNum == 1.4) {
				Scenes.numScene = 14;	 
			} else if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 37;	 
			} 
		} else if (Scenes.numScene == 40) {
			if (CommandCenter.commandNum == 1.3) {
				Scenes.numScene = 21;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 47;
			}
		} else if (Scenes.numScene == 41) {
			if (CommandCenter.commandNum == 1.2) {
				Scenes.numScene = 4;	 
			} else if (CommandCenter.commandNum == 1.1) {
				Scenes.numScene = 38;
			}
		} 
		
		if (Scenes.numScene == 49) {
			if (CommandCenter.commandNum == 2.4) {
				Player.bananaCount=1;
				System.out.println("You have BENJI_THE_PLANT\n\n\n\n\n\nUSE HIM");
				Player.benji = 1;
			} 
		}
		
		if (Scenes.numScene == Player.bananaLoc) {
			if (CommandCenter.commandNum == 2.1) {
				Player.bananaCount=1;
				Player.bananaLoc = 0;
				System.out.println("Banana added to inventory.");
			} 
		} else if (Scenes.numScene == Player.banana2Loc) {
			if (CommandCenter.commandNum == 2.1) {
				Player.bananaCount=1;
				Player.banana2Loc = 0;
				System.out.println("Banana added to inventory.");
			} 
		} else if (Scenes.numScene == Player.banana3Loc) {
			if (CommandCenter.commandNum == 2.1) {
				Player.bananaCount=1;
				Player.banana3Loc = 0;
				System.out.println("Banana added to inventory.");
			} 
		}
		if (Scenes.numScene == Player.bottleLoc) {
			if (CommandCenter.commandNum == 2.2) {
				Player.bottleCount=3;
				Player.bottleLoc = 0;
				System.out.println("Water Bottle added to inventory.");
			} 
		} else if (Scenes.numScene == Player.bottle3Loc) {
			if (CommandCenter.commandNum == 2.2) {
				Player.bottleCount=3;
				Player.bottle3Loc = 0;
				System.out.println("Water Bottle added to inventory.");
			} 
		} else if (Scenes.numScene == Player.bottle2Loc) {
			if (CommandCenter.commandNum == 2.2) {
				Player.bottleCount=3;
				Player.bottle2Loc = 0;
				System.out.println("Water Bottle added to inventory.");
			} 
		} else if (Scenes.numScene == Player.bottle4Loc) {
			if (CommandCenter.commandNum == 2.2) {
				Player.bottleCount=3;
				Player.bottle4Loc = 0;
				System.out.println("Water Bottle added to inventory.");
			} 
		} 
		if (Scenes.numScene == Player.flashLoc) {
			if (CommandCenter.commandNum == 2.3) {
				Player.flashCount=1;
				Player.flashLoc = 0;
				System.out.println("Why would you want this though? \nFlashlight added to inventory.");
			} 
		}

		
		if (Player.benji == 1) {
			if (CommandCenter.commandNum == 3.4) {
				System.out.println("\n\n\n\nWhat...");
				Scenes.benjiUse += 1;
				Main2.g += 2;
			} 
		}
		
		if (CommandCenter.commandNum == 3.1) {
			if (Player.bananaCount == 1) {
				Player.bananaCount -= 1;
				System.out.println("You used the banana.");
				Scenes.monkeyCount -= 1;
			} else {
				System.out.println("You don't have that");
			}
		} else if (CommandCenter.commandNum == 3.2) {
			if (Player.bottleCount >= 1) {
				Player.bottleCount -= 1;
				System.out.println("You used the water bottle.");
				if (Monkeys.monkey1Loc == Scenes.numScene) {
					Scenes.monkeyCount -= 1;
					Monkeys.monkey1Loc = 21;
				} else if (Monkeys.monkey2Loc == Scenes.numScene) {
					Scenes.monkeyCount -= 1;
					Monkeys.monkey2Loc = 33;
				} else if (Monkeys.monkey3Loc == Scenes.numScene) {
					Scenes.monkeyCount -= 1;
					Monkeys.monkey3Loc = 19;
				} else if (Monkeys.kevin == Scenes.numScene) {
					Scenes.monkeyCount -= 1;
					Monkeys.kevin += 2;
				}
			} else {
				System.out.println("You don't have that");
			} 
		} else if (CommandCenter.commandNum == 3.3) {
			if (Player.flashCount == 1) {
				Player.flashCount = 2;
				System.out.println("You used the flashlight and nothing happened.");
			} else {
				System.out.println("You don't have that");
			}
		} 
	}
}
