package Game;

import java.io.File;

public class Scenes {
	static int numScene = 0;
	static int monkeyCount = 0;
	static int benjiUse = 0;
	static int x = 0;
	static int m = 0;
	static String [] sceneNum = {"Hello and WELCOME to my fan-made game\n       The Squeeze: \nFINDING salvation_2514109\n\nPlease move Forward to start",
			 "You are in Room 1. At first you hear nothing, then you hear the voice of a girl,\n 'hey' she said, somewhat causing you to jolt slightly. You regain your composure.\n Thinking to yourself, 'A lesser man would have ran from that.' and smirking slightly,\nbut of course you know better than anyone what that noise truly means.\nKevin is here somewhere\n Looking around the room you�ve just realized you have no idea where you are. A pale-ish yellow room with a\n door at the front of the room. A strange predicament to be in.\n\n",
			 "You are in Room 2. Immediately hit with an incredibly bright light you seem to be in a giant eggshell white\n hangar. Very curiously placed in the middle of this weird structure. At the front and back of the room, there seems to be \n two hangar doors that are wide open and pitch black. At the right is a door.\n",
			 "You are in Room 3. It looks like what seems to be a kitchen. However, all of the food has rotted. The stenches\r\n"
			 + " bombard your nose with a powerful musty odor of fungus and rotten food. You want to leave \r\n"
			 + "this room as fast as possible. There is a door at the front and the door at the left. \r\n"
			 + "", 
			 "You are in Room 4. It seems to be a walled-in outdoor pool area. However, the pool is completely dry. Too bad, a\r\n"
			 + " dip would be nice. There is a way forward and a way back.\r\n"
			 + "",
			 "You are in Room 5. It is a wholly normal and totally fine room with absolutely nothing wrong with it. There is a\r\n"
			 + " door at the right and a door at the left.\r\n"
			 + "", 
			 "You are in Room 6. The same as room five but upside down and a bit darker. Also, strange sounds in the walls \r\n"
			 + "are constantly scratched at them to break through. Though the sounds are pretty annoying, you \r\n"
			 + "feel safe that they cannot. There�s a door at the right and the left.\r\n"
			 + "", 
			 "You are in Room 7. An empty hallway. Hallway to the left, hallway to the right and a door behind you.", 
			 "You are in Room 8. You recognize this place. It�s one of the common areas in Benson dormitory. It appears all but\r\n"
			 + " the room at the front is locked. You can see the light from the bathroom to the left. A soft, \r\n"
			 + "inviting glow, as if summoning you to sit on the toilet and read some art of war. Dorm room at\r\n"
			 + " the front and bathroom to the left.\r\n"
			 + "",
			 "You are in Room 9. It�s pitch black. If there are walls, you can�t see them. Judging by what little light you have \r\n"
			 + "with you, the room seems the same as rooms five and six. The atmosphere is heavier, the walls\r\n"
			 + " seem thinner, and the scratching seems much much closer. This feels not safe. This feels like \r\n"
			 + "the opposite of safe. \r\n"
			 + "", 
			 "You are in Room 10. Once you enter the room, it looks like a Waggoner study room. There is a windowed glass \r\n"
			 + "door at the front of the room, which shows the Waggoner library. However, when you turn \r\n"
			 + "around, instead of a windowpane looking out, you see there is the same door with the same \r\n"
			 + "view on the other side, and just like the past doors you went through, you feel that neither of \r\n"
			 + "those leads to the library�a windowed door at the front and a window door at the back.\r\n"
			 + "", 
			 "You are in Room 11. An empty hallway. Hallway to the left, hallway to the right and a door behind you.", 
			 "You are in Room 12. There�s nothing here. A black empty void space occupies every corner of your vision, until \r\n"
			 + "you can somewhat make out what seems to be a moving walkway. Extending into the darkness, \r\n"
			 + "you have two choices. Walkway forward or go back�walkway at the front and door at the back.\r\n"
			 + "",
			 "You are in Room 13. THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE THERE IS NO ESCAPE \r\n"
			 + "Forward?\r\n"
			 + "Backward? \r\n"
			 + "", 
			 "You are in Room 14. An empty hallway. Hallway to the left, hallway to the right and a door behind you.", 
			 "You are in Room 15. This room feels familiar. Snake eye-like insignias line the walls and floors. Do you feel\r\n"
			 + " uncomfortable? They�re looking at you. They see it, you know. They see past your eyes. Your \r\n"
			 + "flesh. They see the exploitable green paint inside. At the right of the room, there is a closet. At \r\n"
			 + "the back, there is a door.  The right or back.\r\n"
			 + "", 
			 "You are in Room 16. The closet is much bigger than it looks from the outside. At the front, there seems to be a \r\n"
			 + "much wider opening. To the left is the snake-eye room. Forward through the opening or left back \r\n"
			 + "to the room.\r\n"
			 + "",
			 "You are in Room 17. You walk into the pews of a chapel. There�s something very eerie about a church at night. \r\n"
			 + "There�s an opening through a window at the front, but it seems too small for you to pass \r\n"
			 + "through. God is not here. The doorways to the right and at the back are open. \r\n"
			 + "", 
			 "You are in Room 18. You make your way towards the stairwell. You recognize it as the stairwell that supposedly\r\n"
			 + " goes down to a pool room and go down to the bottom of the stairs. There is a door to the right \r\n"
			 + "or stairway up. Right or up.\r\n"
			 + "", 
			 "You are in Room 19. Currently the scariest room so far. It�s filled with nothing but anime posters and amiibos. You \r\n"
			 + "recognize this place as Wallance�s room. You must quickly leave this place. There is a door to \r\n"
			 + "your left.\r\n"
			 + "", 
			 "You are in Room 20. An empty hallway. Hallway to the left, hallway to the right and a door behind you.",
			 "You are in Room 21. What seems to be a gym. Multiple corpses are lying on the ground, either smashed by \r\n"
			 + "weights or crushed from being squeezed. It is probably in your better judgment to leave as fast \r\n"
			 + "as possible. You recognize this place as Raymond�s room. There is a door to the left.\r\n"
			 + "", 
			 "There is no chapter 22, go back.", 
			 "You are in Room 23. It seems to be a hallway in between the darkness and the closet. You can feel the changes \r\n"
			 + "from clothes to gross green mold covering and slowly eating away at everything on the walls. \r\n"
			 + "There is darkness at the front and the closet at the back.\r\n"
			 + "", 
			 "You are in Room 24. It seems to be the mailroom. The scent of fresh paper and packages fills the air despite the \r\n"
			 + "entirety of the mailroom being empty. There appears to be an employee room at the front. There \r\n"
			 + "is also a door outside of the mailroom to the left.\r\n"
			 + "",
			 "You are in Room 25. This room is filled wall-to-wall with guns. Giant machine guns that tear holes in buildings like \r\n"
			 + "cutting through a slice of cheese. From handguns to rocket launchers in this room has \r\n"
			 + "everything. But it�s all behind 3mm thick non-shatter-resistant glass, and that would make a \r\n"
			 + "mess, so let�s not touch it. There�s a door at the back and the door at the front.\r\n"
			 + "", 
			 "You are in Room 26. An empty hallway. Hallway to the left, hallway to the right and a door behind you.", 
			 "You are in Room 27. You seem to have entered the passenger seat of a random car. You recognize this car but \r\n"
			 + "can�t put your finger on where you�ve seen it. You find some milk bones sitting in the middle \r\n"
			 + "console. You do not need milk bones. The front windshield of the car seems to be smashed \r\n"
			 + "open enough to crawl through, and the driver side or left side of the vehicle is completely open,\r\n"
			 + " but the back seems a little too smashed to squeeze through. Forward, left or right.\r\n"
			 + "", 
			 "You are in Room 28. You seem to be right in front of Benson ramp. Some pretty dope music starts to play in your \r\n"
			 + "head, and you picture yourself walking down the ramp in a suit and tie, fully ready to fight the \r\n"
			 + "monkeys. Sadly you still know nothing about The Art of War by Sun Tzu. Go forward to the \r\n"
			 + "ramp or go right to the other entrance.\r\n"
			 + "",
			 "You are in Room 29. You seem to be in the washer room. All the machines are running, so you can�t do your \r\n"
			 + "laundry. After bringing in all this way, you put your laundry down, depressed and saddened by \r\n"
			 + "the lack of available laundry machines. There�s a door to your right and a window you could \r\n"
			 + "crawl through to your left. \r\n"
			 + "", 
			 "You are in Room 30. You are in a dark, disgusting room. The walls are covered in slimy fungi mold that is very \r\n"
			 + "visually pulsating like the heart keeping the apparent ever changing building alive. Creepy, man. \r\n"
			 + "There�s a door on either side of the room and one at the back. \r\n"
			 + "", 
			 "You are in Room 31. This room seems to be on fire so personally I�d take what you can and run. There�s a door \r\n"
			 + "on either side and one at the front.\r\n"
			 + "", 
			 "You are in Room 32. This room seems like a trap set up by an idiot. There are 15 alligators who haven�t eaten \r\n"
			 + "anything for four years to stay starving and ravenous. They are all dead. You�re now in a metal\r\n"
			 + " room with 15 smelly dead alligators. There is a door to your left and a door at the back of the \r\n"
			 + "room.\r\n"
			 + "",
			 "You are in Room 33. This room is completely empty. There are no other doors to be seen anywhere. The walls \r\n"
			 + "are made of what seems to be steel or some metallic alloy. There are small holes everywhere in \r\n"
			 + "this room, some larger than others, but none big enough for you. There are trails of blood \r\n"
			 + "leaking from each one. Once you look at the floor you find what appears to be a mashed paste \r\n"
			 + "of human. Human Paste. It�s the signature of our good friend Norman. Catching you off guard \r\n"
			 + "you press a switch on the floor by accident and the walls start to close in slowly. The only door \r\n"
			 + "is the one you came in. One door at the back.\r\n"
			 + "", 
			 "You are in Room 34. You are outside on a very long bridge over a dried up river. The railing is broken with bits \r\n"
			 + "fallen off and the air is filled with a thick brown smog which makes it difficult to see. If you squint \r\n"
			 + "really hard you can barely make out what seems to be a crumbling ruined city far off in the \r\n"
			 + "distance. The silence you hear is almost deafening, you wish for anything, even the sound of \r\n"
			 + "screaming kids at this point. You can either walk left or right down the long broken bridge.\r\n"
			 + "", 
			 "You are in Room 35. You see a room covered in mirrors, they are unusually pristine and taken care of for this \r\n"
			 + "weird dimensional maze you�re in. There are so many mirrors that it covers up most of the walls. \r\n"
			 + "Then you notice the doors or rather the door ways. There is a doorway in each direction but \r\n"
			 + "inside them you see the same room. You also see yourself in that room looking through the \r\n"
			 + "doorways. They create an infinite hallway all the way down with infinite versions of you in the \r\n"
			 + "rooms. You are unsure of which path to go as all four directions appear the same.\r\n"
			 + "", 
			 "You are in Room 36. You look at the four walls around you, and see that they are made of a nice brown \r\n"
			 + "mahogany wood. A closed metal door can be seen on both the left and the right and two \r\n"
			 + "columns of buttons are displayed in front of you. Unfortunately most of the buttons are missing \r\n"
			 + "and only two remain. Pressing one of them takes you to a floor where the door on the left \r\n"
			 + "opens, the other takes you to a floor where the door on the right opens. You get this odd feeling \r\n"
			 + "you are being watched and you look down. A small hole can be seen where someone could \r\n"
			 + "hide out of sight and surprise whoever may be inside.\r\n"
			 + "",
			 "You are in Room 37. You can�t help but have this weird feeling that you have been here before. You can�t tell if it�s \r\n"
			 + "from a distant memory, a dream, or if you are just losing your memory from being in this place \r\n"
			 + "for too long. It�s hard to describe your surroundings but it is very distinct. You�re sure of it now, \r\n"
			 + "you have been here, you just don�t know when. You are sure that if you were ever to see this \r\n"
			 + "room again you would remember it. You may leave this weirdly familiar place via the \r\n"
			 + "passageways on the wall behind you and on the right.\r\n"
			 + "", 
			 "You are in Room 38. You find yourself outside of Benson somehow in an open area. There are pathways leading \r\n"
			 + "in and around the building or so they seem. To your right there is a sealed window that shows a \r\n"
			 + "room with many washers and dryers in them that all seem to be in use. Suddenly you see \r\n"
			 + "yourself walking in with a load of laundry and looking around to see if any are opened. You see \r\n"
			 + "yourself becoming disheartened and depressed as he considers his options of escape around \r\n"
			 + "him. He doesn�t seem to notice you even when he looks directly at you. You decide you have to \r\n"
			 + "leave before something weird happens. You can either walk off forwards, backwards, or towards \r\n"
			 + "your left.\r\n"
			 + "", 
			 "You are in Room 39. An empty hallway. Hallway to the left, hallway to the right and a door behind you.", 
			 "You are in Room 40. You find yourself in a strange cave with weird cuts and markings all over the walls. Like \r\n"
			 + "everywhere else in this forsaken place it�s filled with a dim light that makes everything barely \r\n"
			 + "visible. You keep moving until you find something that sends chills up your spine. Dead Bodies,\r\n"
			 + " everywhere. Some have been more decayed than others. One of the fully decayed bodies has \r\n"
			 + "an eye patch. Wait, most of them do. You can�t stand to look at them much longer and look for \r\n"
			 + "an exit. The cave leads ahead of you and also to your right. The paths darken to pitch black and \r\n"
			 + "you must make a choice.\r\n"
			 + "",
			 "You are in Room 41. The first thing you notice is how similar this place is to the city you live in, except completely \r\n"
			 + "abandoned and run down. A reminder of where you came and hopefully where you will make it \r\n"
			 + "back to. The air consists of a very dark green color and dust can be seen flying everywhere. On\r\n"
			 + " the street you are on there are run down cars with cobwebs all over them, buildings in crumpled\r\n"
			 + " states, and no sign of life that lives except for old trees all around. Unfortunately it seems your \r\n"
			 + "only escape is through a hole in a tree in front or behind you. A shriek can be heard in the \r\n"
			 + "distance. You realize you might not be alone.\r\n"
			 + "", 
			 "You are in Room 42. You find yourself in a room that seems very strange and unusual. It is shaped like and feels \r\n"
			 + "like a normal dorm room but the decorations seem archaic and cryptic. Two beds can be seen, \r\n"
			 + "one elevated and one not. Around the room are various banners. One has a picture of a yellow \r\n"
			 + "dog in a burning room saying 'This is fine,' another has a picture of a chubby asain man with the \r\n"
			 + "quote: 'Live laugh love.' Unfortunately the rest of the banner was torn so that the person could \r\n"
			 + "not be identified. There is a framed sailboat, and a frame of a man with strange hair. Then you \r\n"
			 + "see them. You enter fight or flight mode until you realize they aren�t moving. There are monkeys \r\n"
			 + "hanging in the room. It looks like the monkeys that are chasing you, but there are more of them, \r\n"
			 + "many more. You breathe a sigh of relief when you see there is no danger. You wish to stay and \r\n"
			 + "explore but you need to go. Benji�s waiting. There's a door behind you. there's a also a closet to the leftish of the door. \nAnd a noticable size hole or gap in the floor to the right. \n Door behind, closet to the left, gap to the right or window in front.\r\n"
			 + "", 
			 "You are in Room 43. As soon as you step in, you can feel the cold air brushing past your face. You immediately \r\n"
			 + "get goosebumps not only from the freezing temperatures but also from the bodies being stored \r\n"
			 + "there. �A mortuary� you think to yourself sarcastically. �Of course why not.� You see the tiny \r\n"
			 + "entrance that  small creatures could enter and you realize quickly what that means. You see a \r\n"
			 + "door in front and a door behind.\r\n"
			 + "", 
			 "You are in Room 44. As you walk further into this room it becomes darker and darker until it eventually turns pitch \r\n"
			 + "black. You think to turn back behind you to the way you came until you see a faint glow off in the \r\n"
			 + "distance. You can�t seem to make out exactly what it is but it does intrigue you. You can either \r\n"
			 + "move forwards or move backwards in this void.\r\n"
			 + "",
			 "You are in Room 45. You find yourself in a very bright and colorful tunnel. It consists of light that rushes past you \r\n"
			 + "creating what appears to be a fast moving tunnel of colorful light. Constantly throughout this \r\n"
			 + "tunnel you see holes open and close revealing locations you have seen and many you have \r\n"
			 + "not. You can�t seem to find a hole that stays open long enough to go through except for one \r\n"
			 + "behind you. You can go backwards or further down the tunnel to the right. \r\n"
			 + "", 
			 "You are in Room 46. You walk further down the dimensional light tunnel and see more and more unique worlds \r\n"
			 + "around you. Again these worlds only appear for mere moments but each one mesmerizes you \r\n"
			 + "as much as the last. You may continue to the left or the right of the tunnel. \r\n"
			 + "", 
			 "You are in Room 47. You find yourself at the end of the light tunnel. You see, yet again, more portals between \r\n"
			 + "worlds. This time two portals seem to stay open for much much longer than the others do. In\r\n"
			 + " fact you haven�t seen them close yet. You peer into the one in front of you and you see what \r\n"
			 + "appears to be an Escher-esque reality where there is no clear sense of up or down anywhere. \r\n"
			 + "The world is made of stairs that seemingly lead to nowhere and defy every law of physics \r\n"
			 + "known to man. The portal behind you is drastically different. You see huge machinery broken \r\n"
			 + "and lying about in the endless sand of the desert you see before you. One giant robot \r\n"
			 + "seemingly walks toward and over the portal you are viewing from. The way it appears is \r\n"
			 + "unfamiliar to you, almost as if it was all a pastel drawing. Both portals make no sense but are \r\n"
			 + "both very interesting to watch. You can walk to the right down the light tunnel, forward into the \r\n"
			 + "portal, or backwards into the other.\r\n"
			 + "", 
			 "you are in room 48. When you finAlly gaTher your senses, you notiCe tHat the enTire room is covered in a weird \r\n"
			 + "projection of a wHitE and black Spiral covering every wall. QUestioning thE extrEme craZiness \r\n"
			 + "of this room, you rEalize that there Are words flashinG on the walls reAlly quIckly. Nausea \r\n"
			 + "begins to overtake you and in a daze you have to make a decision, but you can�t tell which way \r\n"
			 + "to go.\r\n"
			 + "",
			 "You are in\n  The Bathroom "};
	
	static void sceneRun() throws InterruptedException {
	
		Thread.sleep(2000);
		System.out.println(sceneNum[numScene]);
	}
	static void sceneCheck() throws InterruptedException {
		File beepsPath = new File("mixkit-repeating-arcade-beep-1084.wav");
		File beeps = new File(beepsPath.getAbsolutePath());
			Thread.sleep(2000);
		System.out.println("\n\n\n"); 
			
		if (numScene == 49) {
		while (x < 1) {
			System.out.println("You've found it");
			System.out.println("You've found him");
			System.out.println("...");
			System.out.println("Take Benji.");
			x += 1;
		}
		}
		if (numScene == Player.bananaLoc) {
			System.out.println("Also, there happens to be a banana on the floor");
		} else if (numScene == Player.banana2Loc) {
			System.out.println("Also, there happens to be a banana on the floor");
		} else if (numScene == Player.banana3Loc) {
			System.out.println("Also, there happens to be a banana on the floor");
		} else if (numScene == Player.bottleLoc) {
			System.out.println("Also, there happens to be a water bottle on the floor");
		} else if (numScene == Player.bottle2Loc) {
			System.out.println("Also, there happens to be a water bottle on the floor");
		} else if (numScene == Player.bottle3Loc) {
			System.out.println("Also, there happens to be a water bottle on the floor");
		} else if (numScene == Player.bottle4Loc) {
			System.out.println("Also, there happens to be a water bottle on the floor");
		} else if (numScene == Player.flashLoc) {
			System.out.println("Also, Huzzah! A Flashlight! How utterly useless in a text based game with no visuals.");
		}
		
		if (m != 1) {
		if (numScene == Monkeys.monkey1Loc) {
			monkeyCount += 1;
			if (numScene == Monkeys.monkey2Loc) {
				monkeyCount += 1;
				if (numScene == Monkeys.monkey3Loc) {
					monkeyCount += 1;
					if (numScene == Monkeys.kevin) {
						monkeyCount += 1;
					}
				}
			} else if (numScene == Monkeys.monkey3Loc) {
				monkeyCount += 1;
				if (numScene == Monkeys.kevin) {
					monkeyCount += 1;
				}
			} else if (numScene == Monkeys.kevin) {
				monkeyCount += 1;
			}
		} else if (numScene == Monkeys.monkey2Loc) {
			monkeyCount += 1;
			if (numScene == Monkeys.monkey1Loc) {
				monkeyCount += 1;
				if (numScene == Monkeys.monkey3Loc) {
					monkeyCount += 1;
				}
			} else if (numScene == Monkeys.monkey3Loc) {
				monkeyCount += 1;
			}
		} else if (numScene == Monkeys.monkey3Loc) {
			monkeyCount += 1;
			if (numScene == Monkeys.monkey1Loc) {
				monkeyCount += 1;
				if (numScene == Monkeys.monkey2Loc) {
					monkeyCount += 1;
					if (numScene == Monkeys.kevin) {
						monkeyCount += 1;
					}
				} 
			} else if (numScene == Monkeys.monkey2Loc) {
				monkeyCount += 1;
				if (numScene == Monkeys.kevin) {
					monkeyCount += 1;
				}
			} else if (numScene == Monkeys.kevin) {
				monkeyCount += 1;
			}
		} else if (numScene == Monkeys.kevin) {
			monkeyCount += 1;
		}
		}
		
		if (numScene == Monkeys.monkey1Loc) {
			m = 1;
			System.out.println("THERE'S A MONKEY IN HERE");
			if (numScene == Monkeys.monkey2Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
				if (numScene == Monkeys.monkey3Loc) {
					m = 1;
					System.out.println("THERE'S THREE MONKEYS IN HERE");
					if (numScene == Monkeys.kevin) {
						System.out.println("KEVIN IS IN HERE");
						m = 1;
					}
				}
			} else if (numScene == Monkeys.monkey3Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
				if (numScene == Monkeys.kevin) {
					System.out.println("THERE'S THREE MONKEYS IN HERE");
					m = 1;
				}
			} else if (numScene == Monkeys.kevin) {
				System.out.println("KEVIN IS IN HERE");
				m = 1;
			}
		} else if (numScene == Monkeys.monkey2Loc) {
			m = 1;
			System.out.println("THERE'S A MONKEY IN HERE");
			if (numScene == Monkeys.monkey1Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
				if (numScene == Monkeys.monkey3Loc) {
					m = 1;
					System.out.println("THERE'S THREE MONKEYS IN HERE");
				}
			} else if (numScene == Monkeys.monkey3Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
			}
		} else if (numScene == Monkeys.monkey3Loc) {
			m = 1;
			System.out.println("THERE'S A MONKEY IN HERE");
			if (numScene == Monkeys.monkey1Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
				if (numScene == Monkeys.monkey2Loc) {
					m = 1;
					System.out.println("THERE'S THREE MONKEYS IN HERE");
					if (numScene == Monkeys.kevin) {
						System.out.println("KEVIN IS IN HERE");
						m = 1;
					}
				} 
			} else if (numScene == Monkeys.monkey2Loc) {
				m = 1;
				System.out.println("THERE'S TWO MONKEYS IN HERE");
				if (numScene == Monkeys.kevin) {
					System.out.println("KEVIN IS IN HERE");
					m = 1;
				}
			} else if (numScene == Monkeys.kevin) {
				System.out.println("KEVIN IS IN HERE");
				m = 1;
			}
		} else if (numScene == Monkeys.kevin) {
			System.out.println("KEVIN IS IN HERE");
			m = 1;
		} else {
			m = 0;
			monkeyCount = 0;
			Main2.PlaySound(beeps);
				Thread.sleep(200);
			System.out.println("The Monkeys are in rooms:");
				Thread.sleep(200);
			System.out.println("Raymond: ");
				Thread.sleep(200);
			System.out.println(Monkeys.monkey1Loc);
				Thread.sleep(200);
			System.out.println("Norman: ");
				Thread.sleep(200);
			System.out.println(Monkeys.monkey2Loc);
				Thread.sleep(200);
			System.out.println("Wallance: ");
				Thread.sleep(200);
			System.out.println(Monkeys.monkey3Loc);
				Thread.sleep(200);
			System.out.println("KEVIN: ");
				Thread.sleep(200);
			System.out.println(Monkeys.kevin);
				Thread.sleep(200);
			System.out.println("\n\n\n");
		}
		
	}
	
}
