package DatingSim;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.concurrent.ThreadLocalRandom;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.Border;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

public class Board extends JPanel implements ActionListener {

	private Image background1;
	private Image background2;
	private Image background3;
	private Image background4;
	private Image Caleb;
	private Image CalebHurt;
	private Image CalebHit;
	private Image Calebloss;
	private Image kevin;
	private Image Norman;
	private Image Wallance;
	private Image Raymond;
	private Image Thomas;
	private Image CCT;
	private Image SnakeEyes;
	private Image Logo;
	private Image Petals;
	private Image UnCaleb;
	private Image UnThomas;
	private Image Unkevin;
	private Image Unnorman;
	private Image Unwallance;
	private Image UnRaymond;
	private JPanel Start_button = new JPanel();
	private JPanel Contin_button = new JPanel();
	private JPanel Choice_buttons = new JPanel();
	private static Timer timer;
	private int y = 1;
	private int z = 1;
	private int a = 1;
	private int b = 4;
	private int x = 1;
	private int m = 1;
	private int wow = 1;
	private static int Time = 150;
	private static int i = 0;
	private int petal = 0;
	private JButton Play = new JButton("Play Game");
	private JButton Play2 = new JButton("Main Menu");
	private static JButton HelpBtn = new JButton("Help");
	private static JButton ContinButton = new JButton();
	private static JButton Select1Button = new JButton();
	private static JButton Select2Button = new JButton();
	private static JButton Select3Button = new JButton();
	private static JButton Select4Button = new JButton();
	private static JTextPane txtArea = new JTextPane();
	
	public Board() {
		
		initBoard();
		
	}
	
	private void initBoard() {
		
		loadBackground();
		
		event ev = new event();
		event2 ev2 = new event2();
		event3 ev3 = new event3();
		event4 select1 = new event4();
		event5 select2 = new event5();
		event6 select3 = new event6();
		event7 select4 = new event7();

		add(Start_button);
		ContinButton.setHorizontalAlignment(SwingConstants.LEFT);
        ContinButton.setVerticalAlignment(SwingConstants.TOP);
        ContinButton.setPreferredSize(new Dimension((Main.s_Width - (Main.s_Width/15)), 400));
		Play.setPreferredSize(new Dimension(Main.s_Width/4 , Main.s_Height/15));
		Start_button.setLayout(null);
		Play.setBounds(Main.s_Width/2 - 150, Main.s_Height/2 - 25, 300, 50);
		Start_button.add(Play);
		Play2.setBounds(Main.s_Width/64, Main.s_Height/72, 100, 25);
		Start_button.add(Play2);
		HelpBtn.setBounds(Main.s_Width/64, Main.s_Height/15, 100, 25);
		Start_button.add(HelpBtn);
		Select1Button.setBounds(15, Main.s_Height/2 + Main.s_Height/5, Main.s_Width/2 - 30, Main.s_Height/9);
		Start_button.add(Select1Button);
		Select2Button.setBounds((Main.s_Width/2 - 30) + 30, (Main.s_Height/2 + Main.s_Height/5), Main.s_Width/2 - 30, Main.s_Height/9);
		Start_button.add(Select2Button);
		Select3Button.setBounds(15, (Main.s_Height/2 + Main.s_Height/5) + Main.s_Height/9 + 15, Main.s_Width/2 - 30, Main.s_Height/9);
		Start_button.add(Select3Button);
		Select4Button.setBounds((Main.s_Width/2 - 30) + 30, (Main.s_Height/2 + Main.s_Height/5) + 15 + Main.s_Height/9, Main.s_Width/2 - 30, Main.s_Height/9);
		Start_button.add(Select4Button);
		ContinButton.setBounds(40, (Main.s_Height/2 + Main.s_Height/5), Main.s_Width - 80, Main.s_Height/4);
		Start_button.add(ContinButton);
		txtArea.setBounds(40, (Main.s_Height/2 + Main.s_Height/5), Main.s_Width - 80, Main.s_Height/4);
		Start_button.add(txtArea);
		Play.setBackground(new Color(200, 150, 200));
		Play2.setBackground(new Color(200, 150, 200));
		HelpBtn.setBackground(new Color(200, 150, 200));
		Select1Button.setBackground(new Color(200, 150, 200));
		Select2Button.setBackground(new Color(200, 150, 200));
		Select3Button.setBackground(new Color(200, 150, 200));
		Select4Button.setBackground(new Color(200, 150, 200));
		txtArea.setBackground(new Color(200, 150, 200));
		Play.addActionListener(ev);
		Start_button.setSize(Main.s_Width, Main.s_Height);
		Start_button.setBackground(null);
		Start_button.setOpaque(false);
		Start_button.setPreferredSize(Main.screenSize);
		ContinButton.setOpaque(false);
		ContinButton.setBorderPainted(false);
		ContinButton.setContentAreaFilled(false);
		ContinButton.repaint();
		HelpBtn.setVisible(false);
		ContinButton.setVisible(false);
		txtArea.setVisible(false);
		Select1Button.setVisible(false);
		Select2Button.setVisible(false);
		Select3Button.setVisible(false);
		Select4Button.setVisible(false);
		ContinButton.addActionListener(ev2);
		Play2.addActionListener(ev3);
		Select1Button.addActionListener(select1);
		Select2Button.addActionListener(select2);
		Select3Button.addActionListener(select3);
		Select4Button.addActionListener(select4);
		
		int w = background1.getWidth(this);
        int h =  background1.getHeight(this);
        setPreferredSize(new Dimension(w, h));
        timer = new Timer(Time, this);
        timer.start();
	}
	
	private void loadBackground() {
		
		ImageIcon i = new ImageIcon("Wallpaper.jpg");
		ImageIcon ii = new ImageIcon("Wallpaper2.jpg");
		ImageIcon iii = new ImageIcon("Background3.jfif");
		ImageIcon iiii = new ImageIcon("Midscreen.jfif");
		ImageIcon caleb = new ImageIcon("Caleb.png");
		ImageIcon calebHurt = new ImageIcon("Caleb_hurt.png");
		ImageIcon calebHit = new ImageIcon("Calebhit.jfif");
		ImageIcon calebLoss = new ImageIcon("Caleb loss.jpg");
		ImageIcon thomas = new ImageIcon("Thomas.png");
		ImageIcon Kevin = new ImageIcon("Kevin.jpg");
		ImageIcon norman = new ImageIcon("Norman.jpg");
		ImageIcon wallance = new ImageIcon("Wallance.jpg");
		ImageIcon raymond = new ImageIcon("Raymond.jpg");
		ImageIcon logo = new ImageIcon("Title.png");
		ImageIcon petals = new ImageIcon("Petals.png");
		ImageIcon calebUnselect = new ImageIcon("CalebUnselected.png");
		ImageIcon thomasUnselect = new ImageIcon("ThomasUnselected.png");
		ImageIcon kevinUnselect = new ImageIcon("KevinUnselected.png");
		ImageIcon raymondUnselect = new ImageIcon("RaymondUnselected.png");
		ImageIcon normanUnselect = new ImageIcon("NormanUnselected.png");
		ImageIcon wallanceUnselect = new ImageIcon("WallanceUnselected.png");
		background1 = i.getImage().getScaledInstance(Main.s_Width, Main.s_Height, Image.SCALE_SMOOTH);
		background2 = ii.getImage().getScaledInstance(Main.s_Width, Main.s_Height, Image.SCALE_SMOOTH);
		background3 = iii.getImage().getScaledInstance(Main.s_Width, Main.s_Height, Image.SCALE_SMOOTH);
		background4 = iiii.getImage().getScaledInstance(Main.s_Width, Main.s_Height, Image.SCALE_SMOOTH);
		Caleb = caleb.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		CalebHurt = calebHurt.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		CalebHit = calebHit.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		Calebloss = calebLoss.getImage().getScaledInstance(Main.s_Width, Main.s_Height, Image.SCALE_SMOOTH);
		Thomas = thomas.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		kevin = Kevin.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		Norman = norman.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		Wallance = wallance.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		Raymond =raymond.getImage().getScaledInstance(Main.s_Width/4, (Main.s_Height/7) * 4, Image.SCALE_SMOOTH);
		Logo = logo.getImage().getScaledInstance(Main.s_Width/2, (Main.s_Height/2) - (Main.s_Height/12), Image.SCALE_SMOOTH);
		Petals = petals.getImage().getScaledInstance(Main.s_Width +200, Main.s_Height+400, Image.SCALE_SMOOTH);
		UnCaleb = calebUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
		UnThomas = thomasUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
		Unkevin = kevinUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
		Unnorman = normanUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
		UnRaymond = raymondUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
		Unwallance = wallanceUnselect.getImage().getScaledInstance(Main.s_Width/4 - 30, (Main.s_Height/7) * 4 - 30, Image.SCALE_SMOOTH);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		int calebPlacementW = Main.s_Width/21;
		int otherCharPlace = Main.s_Width/2 + Main.s_Width/4 - Main.s_Width/21;
		int megaHPlacement = Main.s_Height/3;
		switch (Scenes.sceneType) {
			case 0:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Petals, 0, petal + 0, this);
				g.drawImage(Petals, 0, petal -  (Main.s_Height+400), this);
				g.drawImage(Caleb, calebPlacementW, y + megaHPlacement, this);
				g.drawImage(kevin, otherCharPlace, z + megaHPlacement, this);
				g.drawImage(Logo, Main.s_Width/4, a + Main.s_Height/36, this);
				break;
			case 1:
				g.drawImage(background2, 0, 0, null);
				g.drawImage(UnCaleb, calebPlacementW, y + megaHPlacement, this);
				break;
			case 2:
				g.drawImage(background2, 0, 0, null);
				g.drawImage(Caleb,calebPlacementW, megaHPlacement, this);
				break;
			case 3:
				g.drawImage(Calebloss, 0, 0, null);
				break;
			case 4:
				g.drawImage(background2, 0, 0, null);
				g.drawImage(Caleb,calebPlacementW, megaHPlacement, this);
				g.drawImage(CalebHurt, y + calebPlacementW, megaHPlacement, this);
				break;
			case 5:
				g.drawImage(background3, 0, 0, null);
				g.drawImage(Petals, 0, petal + 0, this);
				g.drawImage(Petals, 0, petal -  (Main.s_Height+400), this);
				g.drawImage(Thomas, otherCharPlace - wow, megaHPlacement - wow, this);
				break;
			case 6:
				g.drawImage(background3, 0, 0, null);
				g.drawImage(Caleb, calebPlacementW, megaHPlacement, this);
				g.drawImage(UnThomas,otherCharPlace, z + megaHPlacement, this);
				break;
			case 7:
				g.drawImage(background3, 0, 0, null);
				g.drawImage(UnCaleb, calebPlacementW, y + megaHPlacement, this);
				g.drawImage(Thomas, otherCharPlace, megaHPlacement, this);
				break;
			case 8:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Caleb, calebPlacementW, megaHPlacement, this);
				g.drawImage(UnThomas,otherCharPlace, z + megaHPlacement, this);
				break;
			case 9:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(UnCaleb, calebPlacementW, y + megaHPlacement, this);
				g.drawImage(Thomas, otherCharPlace, megaHPlacement, this);
				break;
			case 10:
				g.drawImage(background4, 0, 0, null);
				break;
			case 11:
				g.drawImage(background1, 0, 0 - wow, null);
				g.drawImage(Caleb, calebPlacementW + wow, megaHPlacement - wow, this);
				g.drawImage(kevin, otherCharPlace - wow, megaHPlacement/4 + wow, this);
				g.drawImage(Petals, 0, petal + 0, this);
				g.drawImage(Petals, 0, petal -  (Main.s_Height+400), this);
				break;
			case 12:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Caleb,calebPlacementW, megaHPlacement, this);
				g.drawImage(CalebHurt, y + calebPlacementW, megaHPlacement, this);
				g.drawImage(UnThomas,otherCharPlace, z + megaHPlacement, this);
				break;
			case 13:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(CalebHit, calebPlacementW, megaHPlacement, this);
				g.drawImage(UnThomas,otherCharPlace, z + megaHPlacement, this);
				break;
			case 14:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Caleb, calebPlacementW, megaHPlacement, this);
				g.drawImage(UnRaymond,otherCharPlace, z + megaHPlacement, this);
				break;
			case 15:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(UnCaleb, calebPlacementW, y + megaHPlacement, this);
				g.drawImage(Raymond,otherCharPlace, megaHPlacement, this);
				break;
			case 16:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Caleb, calebPlacementW, megaHPlacement, this);
				g.drawImage(Raymond, otherCharPlace - wow, megaHPlacement/4, this);
				g.drawImage(Petals, 0, petal + 0, this);
				g.drawImage(Petals, 0, petal -  (Main.s_Height+400), this);
				break;
			case 17:
				g.drawImage(background1, 0, 0, null);
				g.drawImage(Caleb, calebPlacementW, megaHPlacement, this);
				g.drawImage(Raymond, otherCharPlace, megaHPlacement, this);
				g.drawImage(Petals, 0, petal + 0, this);
				g.drawImage(Petals, 0, petal -  (Main.s_Height+400), this);
				break;
			
		}

	}
	
	 @Override
	    public void actionPerformed(ActionEvent e) {
		 x += 1;
		 b += 1;
		 petal += 4;
		 if (Scenes.sceneNum == 16 || Scenes.sceneNum == 17 ||Scenes.sceneNum == 18 ||Scenes.sceneNum == 19 || Scenes.sceneNum == 31 ||Scenes.sceneNum == 75 ) {
			 m += 1;
		 } else {
			 m = 1;
		 }
		 y = (int) (5*Math.cos(x));
		 z = (int) (5*Math.sin(x));
		 a = (int) (5*Math.cos(b));
		 wow = (int) (4000/m);
		 
		 if (petal == (Main.s_Height + 400)) {
			 petal = 0;
		 }
		 
		 repaint();
	 }
	 
	 public class event implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent ev) {
		 Scenes.sceneNum = 1;
		 Scenes.sceneType = 1;
		 Play.setVisible(false);
		 ContinButton.setVisible(true);
		 txtArea.setVisible(true);
		 i = 0;
		 txtArea.setText(null);
		 }

	}
	 public class event2 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent ev2) {
		 Scenes.sceneNum++;
		 txtArea.setText(null);
		 appendToText(txtArea, Scenes.nextLine[i], Color.WHITE);
		 Select1Button.setText(Scenes.nextLine[i]);
		 Select2Button.setText(Scenes.nextLine[i+1]);
		 Select3Button.setText(Scenes.nextLine[i+2]);
		 Select4Button.setText(Scenes.nextLine[i+3]);
		 i++;
		 sceneCheck();
		 }

	}
	 public class event3 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent ev3) {
		 Scenes.sceneNum = 0;
		 Scenes.sceneType = 0;

		 Play.setVisible(true);
		 ContinButton.setVisible(false);
		 txtArea.setVisible(false);
		 Select1Button.setVisible(false);
		 Select2Button.setVisible(false);
		 Select3Button.setVisible(false);
		 Select4Button.setVisible(false);
		 }

	}
	 public class event4 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent select1) {
			 txtArea.setText(null);
			 appendToText(txtArea, Scenes.nextLine[i - 1], Color.WHITE);
			 switch(Scenes.sceneNum) {
			 
			 case 7:
				 Scenes.sceneType = 2;
				 Scenes.sceneNum = 130;
				 i = 130;
				  break;
			 case 22:
				 Scenes.sceneType = 6;
				 Scenes.sceneNum = 171;
				 i = 171;
				 break;
			 case 39:
				 Scenes.sceneType = 8;
				 Scenes.sceneNum = 43;
				 i = 43;
				 break;
			 }
			 sceneCheck();
		 }

	}
	 public class event5 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent select2) {
			 txtArea.setText(null);
			 appendToText(txtArea, Scenes.nextLine[i], Color.WHITE);
			 switch(Scenes.sceneNum) {
			 
			 case 7:
				 Scenes.sceneType = 1;
				 Scenes.sceneNum = 135;
				 i = 135;
				  break;
			 case 22:
				 Scenes.sceneType = 6;
				 Scenes.sceneNum = 180;
				 i = 180;
				 break;
			 case 39:
					Scenes.sceneType = 8;
					Scenes.sceneNum = 53;
					 i = 53;
					 break;
			 }
			 sceneCheck();
		 }

	}
	 public class event6 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent select3) {
			 txtArea.setText(null);
			 appendToText(txtArea, Scenes.nextLine[i+1], Color.WHITE);
			 switch(Scenes.sceneNum) {
			 
			 case 7:
				 Scenes.sceneType = 1;
				 Scenes.sceneNum = 135;
				 i = 135;
				  break;
			 case 22:
				 Scenes.sceneType = 6;
				 Scenes.sceneNum = 188;
				 i = 188;
				 break;
			 case 39:
					Scenes.sceneType = 3;
					Scenes.sceneNum = 212;
					 i = 212;
					 txtArea.setText(null);
					appendToText(txtArea, Scenes.nextLine[213], Color.WHITE);
					 break;
			 }
			 sceneCheck();
		 }

	}
	 public class event7 implements ActionListener {
		 @Override
		 public void actionPerformed(ActionEvent select4) {
			 txtArea.setText(null);
			 appendToText(txtArea, Scenes.nextLine[i+2], Color.WHITE);
			 switch(Scenes.sceneNum) {
			 
			 case 7:
				Scenes.sceneType = 3;
				 Scenes.sceneNum = 212;
				 i = 212;
				 txtArea.setText(null);
				 appendToText(txtArea, Scenes.nextLine[213], Color.WHITE);
				 break;
			 case 22:
				 Scenes.sceneType = 6;
				 Scenes.sceneNum = 200;
				 i = 200;
				 break;
			 case 39:
				 Scenes.sceneType = 8;
				 Scenes.sceneNum = 59;
				 i = 59;
				 break;
			 }
			 sceneCheck();
		 }

	}
	 public static void appendToText(JTextPane tp, String msg, Color c) {
	        StyleContext sc = StyleContext.getDefaultStyleContext();
	        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

	        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
	        
	        	aset = sc.addAttribute(aset, StyleConstants.FontSize, 20);
	        
	        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

	        int len = tp.getDocument().getLength();
	        tp.setCaretPosition(len);
	        tp.setCharacterAttributes(aset, false);
	        tp.replaceSelection(msg);
	    }
	 
	 public static void sceneCheck() {
		 	switch (Scenes.sceneNum) {
		 	case 7, 22, 39:
				ContinButton.setVisible(false);
				txtArea.setVisible(false);
				Select1Button.setVisible(true);
				Select2Button.setVisible(true);
				Select3Button.setVisible(true);
				Select4Button.setVisible(true);
				break;
		 	case 16:
		 		Scenes.sceneType = 5;
				 break;
		 	case 19:
		 		HelpBtn.setVisible(true);
				 break;
		 	case 27:
		 		Scenes.sceneType = 10;
				 break;
		 	case 31:
		 		Scenes.sceneType = 11;
		 		break;
		 	case 32, 37, 44, 46, 48, 50, 55, 57, 61, 63, 66, 68, 70, 73:
		 		Scenes.sceneType = 8;
		 		break;
		 	case 35, 38, 45, 47, 49, 51, 54, 56, 60, 62, 67, 69:
		 		Scenes.sceneType = 9;
		 		break;
		 	case 36, 72:
		 		Scenes.sceneType = 12;
		 		break;
		 	case 71:
		 		Scenes.sceneType = 13;
		 		break;
		 	case 75:
		 		Scenes.sceneType = 16;
		 		break;
		 	case 76:
		 		Scenes.sceneType = 17;
		 		break;
		 	case 77, 80 :
		 		Scenes.sceneType = 14;
		 		break;
		 	case 79, 82:
		 		Scenes.sceneType = 15;
		 		break;
		 	case 20, 23, 175, 178, 182, 184, 186, 190, 192, 194, 197, 202, 205, 207:
		 		Scenes.sceneType = 6;
				 break;
		 	case 21, 173, 177, 181, 183, 185, 189, 193, 196, 201, 203, 206:
		 		Scenes.sceneType = 7;
				 break;
		 	case 134, 170:
		 		Scenes.sceneNum = 10;
				 i = 10;
				 break;
		 	case 143, 158:
		 		Scenes.sceneType = 4;
		 		 break;
		 	case 144, 159:
		 		Scenes.sceneType = 2;
		 		 break;
		 	case 179, 187, 199, 208:
		 		Scenes.sceneType = 7;
		 		Scenes.sceneNum = 26;
				 i = 26;
				 break;
		 	case 52, 58, 64:
		 		Scenes.sceneType = 8;
		 		Scenes.sceneNum = 65;
				 i = 65;
				 break;
		 	case 214:
		 		System.exit(0);
		 		break;
			default:
				txtArea.setVisible(true);
				ContinButton.setVisible(true);
				Select1Button.setVisible(false);
				Select2Button.setVisible(false);
				Select3Button.setVisible(false);
				Select4Button.setVisible(false);
				break;		 	}
				
	 }
}

