package Game;
import java.util.concurrent.ThreadLocalRandom;


public class Player {
	
 static int bananaCount = 0;
 static int bottleCount = 1;
 static int flashCount = 0;
 static int benji = 0;
 
 static int bananaLoc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int banana2Loc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int banana3Loc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int flashLoc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int bottleLoc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int bottle2Loc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int bottle3Loc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static int bottle4Loc = ThreadLocalRandom.current().nextInt(1, 45 + 1);
 static final int benjiThePlant = 49;
 
}
