module Game_Project {
	requires java.desktop;
}