package DatingSim;


import java.awt.*;

public abstract class imageGet {
		
	public abstract void imageGet(Image in);
	
	public abstract Image getImage();

}
